import { useState } from 'react';
import {
  Landmark,
  ArrowRight,
  Zap,
  Building2,
  Plug,
  Flame,
  Leaf,
  ShieldCheck,
  Info,
  X,
  ExternalLink,
} from 'lucide-react';
import { Modal } from '@/components/Modal';
import { governmentServices, type GovernmentService } from '@/data/mockData';

const categoryIcons: Record<string, typeof Landmark> = {
  'State Government': Landmark,
  'Industrial Safety': ShieldCheck,
  'Power & Energy': Plug,
  'Land & Infrastructure': Building2,
  'Fire Safety': Flame,
  'Environment': Leaf,
  'Central Government': Building2,
};

const categoryColors: Record<string, string> = {
  'State Government': 'from-brand-500 to-brand-700',
  'Industrial Safety': 'from-warning-400 to-warning-600',
  'Power & Energy': 'from-accent-400 to-accent-600',
  'Land & Infrastructure': 'from-success-400 to-success-600',
  'Fire Safety': 'from-error-400 to-error-600',
  'Environment': 'from-success-400 to-accent-600',
  'Central Government': 'from-brand-500 to-accent-600',
};

interface GovernmentServicesPageProps {
  onNavigateToApprovals: () => void;
}

export function GovernmentServicesPage({ onNavigateToApprovals }: GovernmentServicesPageProps) {
  const [selectedService, setSelectedService] = useState<GovernmentService | null>(null);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center">
            <Landmark size={22} className="text-brand-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Government Services</h1>
            <p className="text-gray-600">Access important industrial services from one place.</p>
          </div>
        </div>
      </div>

      {/* Service cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {governmentServices.map((service, i) => {
          const Icon = categoryIcons[service.category] || Landmark;
          const color = categoryColors[service.category] || 'from-brand-500 to-brand-700';
          return (
            <div
              key={service.id}
              className="card card-hover p-6 animate-slide-up"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4`}>
                <Icon size={24} className="text-white" />
              </div>
              <h3 className="font-semibold text-gray-900">{service.name}</h3>
              <p className="text-sm text-gray-600 mt-1 mb-3">{service.description}</p>
              <span className="inline-block text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 mb-4">
                {service.category}
              </span>
              <button
                onClick={() => setSelectedService(service)}
                className="btn-secondary w-full text-sm"
              >
                View Service <ArrowRight size={14} />
              </button>
            </div>
          );
        })}
      </div>

      {/* Integration note */}
      <div className="card p-5 bg-brand-50 border-brand-100">
        <div className="flex items-start gap-3">
          <Info size={20} className="text-brand-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-gray-900">Portal Integration Preview</p>
            <p className="text-sm text-gray-600 mt-1">
              Government portal integration will be connected through secure REST APIs in the production version.
              This prototype demonstrates the unified access experience.
            </p>
          </div>
        </div>
      </div>

      {/* Service modal */}
      <Modal
        isOpen={!!selectedService}
        onClose={() => setSelectedService(null)}
        title={selectedService?.name}
      >
        {selectedService && (
          <div className="space-y-4">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${categoryColors[selectedService.category] || 'from-brand-500 to-brand-700'} flex items-center justify-center`}>
              {(() => {
                const Icon = categoryIcons[selectedService.category] || Landmark;
                return <Icon size={32} className="text-white" />;
              })()}
            </div>
            <p className="text-sm text-gray-600">{selectedService.description}</p>
            <div className="card p-4 bg-gray-50">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={16} className="text-brand-600" />
                <p className="text-sm font-semibold text-gray-900">Available Actions</p>
              </div>
              <ul className="text-sm text-gray-600 space-y-1.5">
                <li>• Track existing applications</li>
                <li>• Submit new applications</li>
                <li>• View department notifications</li>
                <li>• Download approved documents</li>
              </ul>
            </div>
            <div className="card p-4 bg-warning-50 border-warning-200">
              <div className="flex items-start gap-2">
                <Info size={16} className="text-warning-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-warning-800">
                  Government portal integration will be connected through secure REST APIs. No live API is connected in this prototype.
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setSelectedService(null);
                  onNavigateToApprovals();
                }}
                className="btn-primary flex-1"
              >
                View My Applications <ArrowRight size={16} />
              </button>
              <button onClick={() => setSelectedService(null)} className="btn-secondary">
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
